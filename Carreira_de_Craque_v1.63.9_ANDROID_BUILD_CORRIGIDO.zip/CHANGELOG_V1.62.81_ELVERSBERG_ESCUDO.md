# Carreira de Craque v1.62.81 — Ajuste definitivo do escudo do SV Elversberg

- Corrigida a margem transparente excessiva no PNG do SV Elversberg.
- O escudo agora ocupa praticamente toda a área disponível, mantendo proporção, transparência nos cantos e cores originais.
- Mantido o destaque de tamanho na tabela e nas demais telas que usam `crest()`.
- Nenhuma alteração em calendário, partidas, elencos ou saves.
