# v1.62.46 — Logo Sub-20 no mesmo tamanho das demais ligas

- Ajustada a exibição do logo do Brasileirão Sub-20 para usar a mesma área visual (112 × 62 px) aplicada às logos oficiais das outras competições na tela Ligas.
- Mantido o PNG transparente enviado pelo usuário.
- Nenhuma outra competição, tabela, calendário ou sistema foi alterado.
- Cache do PWA atualizado.
