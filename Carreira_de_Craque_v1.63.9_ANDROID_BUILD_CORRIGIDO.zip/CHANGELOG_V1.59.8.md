# Carreira de Craque v1.59.8 — Copa do Brasil com 64 clubes

- Copa do Brasil refeita como mata-mata direto com 64 participantes: 20 da Série A, 20 da Série B, 20 da Série C e quatro convidados exclusivos (Uberlândia, ASA, Gama e ABC).
- Todos os 64 clubes começam na 1ª fase: 32 jogos, sem BYE, sem cabeças de chave e sem entrada em fase posterior.
- Progressão validada: 64 → 32 → 16 → 8 → 4 → 2 → campeão.
- Uberlândia, ASA, Gama e ABC receberam escudos por URL, elencos informados pelo usuário e estrelas 2 / 2,5 conforme definido.
- Os quatro convidados não foram incluídos nas divisões A, B ou C, não recebem calendário de Brasileirão e não aparecem como destino de transferência.
- Calendário da Temporada mantém as partidas da Copa em destaque azul junto às partidas do Brasileirão.
- Os jogos dos demais clubes seguem sendo simulados automaticamente pelo motor existente; a partida do clube do usuário permanece jogável.
- Cache PWA atualizado. Limpeza única de carreiras aplicada nesta atualização, conforme autorização permanente do usuário; dados estáticos do jogo preservados.
