# v1.51.6 — Recuperação de calendário inglês
- Detecção de clubes ingleses mais tolerante a acentos, pontuação e variações de nome.
- Se o save estiver em modo Premier League sem partidas do clube no calendário, tenta reconstruir o calendário inglês em vez de bloquear com erro genérico.
- Como os jogos/resultados do calendário ausente não podem ser inferidos com segurança, a recuperação restaura a temporada para continuar; não inventa placares nem declara a temporada concluída.
