# Carreira de Craque v1.62.63 — Status de Ídolo e Solicitação de Camisa

- Adicionados ao menu Jogador → Perfil os indicadores Status de Ídolo e Reputação no Clube.
- Status de Ídolo evolui com o tempo de permanência no clube e títulos conquistados; 100% representa ÍDOLO DO CLUBE.
- Na aba Jogador → Camisa, o atleta seleciona um número e precisa confirmar em SOLICITAR.
- A camisa ocupada só pode ser disputada quando o overall do atleta da carreira for maior que o do atual dono.
- Solicitações aceitas por camisas ocupadas reduzem a reputação em 8 pontos quando o Status de Ídolo estiver abaixo de 70%; com 70% ou mais, há proteção contra essa penalidade.
- Números livres também exigem solicitação explícita; nenhum número é atribuído automaticamente, inclusive após ficar disponível durante uma espera.
- Preservados os demais sistemas e dados da carreira.
