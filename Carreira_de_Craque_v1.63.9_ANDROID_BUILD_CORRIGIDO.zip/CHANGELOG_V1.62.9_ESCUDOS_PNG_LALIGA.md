# v1.62.9 — Padronização dos escudos PNG da LaLiga

- Corrigido o escudo do Valencia: removida a referência GIF e substituída por endereço PNG.
- Padronizados os endereços PNG dos escudos de Barcelona, Villarreal, Deportivo La Coruña, Racing Santander e Málaga.
- Mantidos os 20 clubes da LaLiga, suas estrelas, cores, calendário e integração com a carreira.
- Nenhuma alteração nos sistemas de partidas, classificação, salvamento ou nas demais ligas.

**Nota técnica:** os seis escudos continuam sendo carregados de URLs externas com formato PNG. Os binários não foram incorporados localmente ao ZIP nesta atualização, pois o ambiente de edição não conseguiu baixar os servidores de imagem. A extensão `.png` do endereço não garante, sozinha, que o servidor remoto esteja disponível em todos os dispositivos.
