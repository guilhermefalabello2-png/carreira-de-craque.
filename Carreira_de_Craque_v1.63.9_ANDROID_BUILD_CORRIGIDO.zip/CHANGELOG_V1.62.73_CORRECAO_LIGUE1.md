# Carreira de Craque v1.62.73 — Correção estrutural da Ligue 1

- Corrigida a identificação de carreiras francesas ao abrir e restaurar saves: clubes da Ligue 1 mantêm a chave `ligue1` e o modo de liga europeia.
- Corrigido o carregamento de saves franceses para não cair no fallback do Brasileirão por possuir 18 clubes e 34 rodadas.
- Corrigida a tela Ligas > Europa > França para exibir a classificação e os dados da Ligue 1, em vez da Série A brasileira.
- Criada rotina de reconstrução segura do calendário francês (18 clubes, 34 rodadas, 306 partidas) quando a associação do clube/calendário estiver ausente ou inconsistente.
- Corrigido o encerramento e avanço de temporada para validar o tamanho real da competição, sem exigir 38 rodadas/380 partidas.
- Corrigida a exibição da temporada francesa com 34 rodadas, 306 partidas e 17 jogos por clube.
- Corrigido o calendário após nova temporada e após transferência para clube francês.
- Preservados os sistemas das outras ligas e os dados da carreira; nenhuma limpeza de saves foi adicionada.
