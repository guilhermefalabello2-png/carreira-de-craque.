# Carreira de Craque v1.51.3

- Adicionada opção explícita **Começar nova temporada** no Início e em Partidas quando todos os jogos do atleta na temporada estiverem concluídos.
- A verificação do calendário agora tolera rodadas fora do intervalo e detecta temporadas concluídas pelos jogos realmente disputados, não apenas pelo contador da rodada.
- Ao iniciar a nova temporada, o sistema recupera o avanço quando todas as partidas do atleta já foram registradas, evitando o bloqueio por contador de rodadas desatualizado.
- Corrigida a contagem de títulos profissionais: o atleta só recebe o título da Série correspondente se terminar em 1º lugar na classificação final.
