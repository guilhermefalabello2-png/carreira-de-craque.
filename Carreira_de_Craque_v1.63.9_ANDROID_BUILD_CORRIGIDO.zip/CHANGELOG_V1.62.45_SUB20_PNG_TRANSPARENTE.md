# Carreira de Craque v1.62.45 — Logo Sub-20 em PNG

- Corrigido o recurso exibido na opção Sub-20 dentro de Ligas.
- A imagem enviada pelo usuário foi convertida para PNG RGBA com fundo branco removido (transparência real).
- A opção Sub-20 aponta diretamente para o PNG local incluído no projeto, com versão de cache atualizada.
- As demais logos, competições, calendários, clubes e sistemas não foram alterados.
