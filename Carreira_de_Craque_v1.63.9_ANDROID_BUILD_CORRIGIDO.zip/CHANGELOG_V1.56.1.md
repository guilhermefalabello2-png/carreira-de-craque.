# v1.56.1 — Correção da classificação da liga

- A classificação visível é reconstruída diretamente dos placares persistidos do calendário da própria competição.
- Um placar válido salvo passa a ser reconhecido como partida concluída mesmo se a flag `played` estiver ausente/inconsistente em um caminho antigo de simulação.
- A reconstrução evita contar duas vezes o mesmo confronto e mantém pontos, jogos, vitórias, empates, derrotas, gols pró/contra e saldo derivados dos mesmos resultados exibidos no calendário.
- Não altera calendários, placares, elencos, estrelas, overalls, carreiras ou armazenamento além de normalizar a flag de partidas que já possuem placar.
