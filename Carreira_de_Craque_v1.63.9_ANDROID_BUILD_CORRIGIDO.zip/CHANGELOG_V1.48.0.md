# Carreira de Craque v1.48.0

- Corrigido o uniforme titular do Flamengo com cinco faixas horizontais alternadas: preto, vermelho, preto, vermelho e preto.
- Mangas e faixa superior pretas conectadas visualmente.
- Faixa central preta posicionada na região da numeração.
- Faixa inferior totalmente preta, ampliada lateralmente para evitar frestas vermelhas nas bordas.
- Mantidas as demais funcionalidades e arquivos da versão-base.
