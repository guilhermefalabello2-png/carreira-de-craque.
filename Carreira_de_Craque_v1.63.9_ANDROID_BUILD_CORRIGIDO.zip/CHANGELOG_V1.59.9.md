# Carreira de Craque v1.59.9

- Removido o cartão redundante “ABRIR COPA” da tela Partidas. A Copa do Brasil continua acessível pelo menu Ligas.
- Calendário da temporada em Partidas ordenado numericamente pelo dia do jogo, com separadores por dia e data.
- Jogos do Brasileirão e da Copa do Brasil permanecem na mesma sequência cronológica; partidas da Copa continuam destacadas em azul.
- Atualizado o cache do service worker.
- Limpeza automática dos dados de carreira nesta atualização, conforme autorização do usuário; arquivos, clubes, elencos e escudos preservados.
