# Carreira de Craque v1.62.88 LITE

- Padronizados os logos da Ligue 1 e Bundesliga usando o mesmo componente e dimensões visuais das demais logos europeias.
- Na tela da Bundesliga, removidas as seções Artilharia, Assistências, Estatísticas da Divisão e Histórico de Campeões. A tabela de classificação permanece.
- Mantidas as demais ligas, tabelas, calendário e sistemas do jogo.
