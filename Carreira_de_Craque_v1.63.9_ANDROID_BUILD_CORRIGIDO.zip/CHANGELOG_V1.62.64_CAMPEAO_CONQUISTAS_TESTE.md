# Carreira de Craque v1.62.64 — Celebração de título e teste de Conquistas

- Ao confirmar um título profissional de liga, aparece uma faixa de celebração com “CAMPEÃO!” e o nome do troféu.
- Ao conquistar o Brasileirão Sub-20, a mesma celebração é exibida.
- A conquista da Copa do Brasil também exibe a celebração e é registrada no histórico central de títulos, para aparecer em Legado → Conquistas.
- Os troféus reais continuam aparecendo em Conquistas apenas após confirmação do título.
- Na mesma Área de Testes da tela Escolher País e Clube, foi adicionado “TESTAR CONQUISTA DE TÍTULO”.
- O teste mostra a faixa “CAMPEÃO! — TAÇA DE TESTE” e adiciona imediatamente uma taça identificada como “TESTE” em Jogador → Legado → Conquistas, sem alterar estatísticas, classificação ou competições oficiais.
- Mantidos os recursos da versão v1.62.63 (Status de Ídolo e solicitação de camisa).
