# v1.62.51 — Escudos brasileiros atuais 2026

- Athletico Paranaense: substituído o escudo histórico circular pelo emblema CAP atual de quatro faixas diagonais.
- Atlético Goianiense: substituído o antigo triângulo ACG pelo escudo atual com a cabeça do Dragão.
- Goiás: apontado para o arquivo atual oficial verde e branco.
- Os três endereços atuais foram adicionados à lista de pré-cache offline; após serem carregados online e armazenados pelo navegador, ficam disponíveis offline.
- Nenhuma tabela, elenco, calendário, ID de clube ou sistema de jogo foi alterado.

Fontes visuais: FootyLogos, com páginas de escudos atuais 2026; para Atlético-GO, PNG transparente 512×512 da versão atual.
