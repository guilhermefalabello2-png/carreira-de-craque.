# Carreira de Craque v1.52.0

## Correção de classificação
- A classificação é recalculada a partir dos placares persistidos, evitando depender de contadores desatualizados.
- O cálculo reconhece variações de nomes de clubes (acentos, abreviações e aliases) ao associar resultados à tabela.
- A tela de classificação sincroniza a tabela ativa antes de exibir pontos e posições.
- Vitória = 3 pontos, empate = 1 ponto e derrota = 0 pontos.

## Validação
- Teste automatizado específico de pontos e aliases incluído em `tests/standings-regression.js`.
- O teste geral legado `npm run test:logic` ainda contém uma asserção anterior sobre o elenco inicial que falha independentemente desta correção; não é apresentado como aprovado.
