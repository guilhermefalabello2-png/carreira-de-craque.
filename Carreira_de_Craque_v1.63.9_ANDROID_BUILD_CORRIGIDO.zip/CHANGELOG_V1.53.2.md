# v1.53.2 — Sincronização de acessos e rebaixamentos em Ligas → Brasil

- A seção Ligas → Brasil passa a carregar os participantes atuais de `state.divisions`, em vez de depender exclusivamente das listas fixas iniciais.
- O calendário e a classificação do painel brasileiro são reconstruídos quando a temporada ou os participantes mudam, sem alterar a lógica de cálculo das tabelas.
- A chave `cc_brazil_world_leagues_v123` passa a persistir a lista de clubes por divisão.
- Saves antigos sem a lista explícita de clubes são migrados preservando resultados quando o calendário já corresponde aos participantes atuais.
- Adicionado teste de regressão para acesso/rebaixamento, calendário de 38 rodadas, persistência, virada de temporada e migração de save legado.
