# Carreira de Craque v1.60.2 — Uniforme do Atlético Mineiro

- Corrigida a camisa titular do Atlético Mineiro na prévia do uniforme.
- Aplicadas listras verticais pretas largas desde a parte superior do tronco até a barra.
- Mangas e punhos em preto, mantendo os ombros brancos e a gola preta, seguindo a referência enviada.
- Mantidos o nome e o número personalizados do atleta em preto.
- Alteração restrita ao uniforme titular do Atlético Mineiro; os demais clubes e sistemas do jogo permanecem inalterados.
