# v1.61.9 — Liberação temporária de transferências para teste

- Removida temporariamente a exigência de completar uma temporada inteira no clube atual.
- Agora é possível buscar outro clube, negociar e aceitar/efetivar uma transferência a qualquer momento, respeitando as demais regras do mercado e a confirmação do usuário.
- Esta alteração é destinada a testes; a regra de permanência mínima poderá ser restaurada depois.
