# Carreira de Craque v1.62.76 — Estrelas da Ligue 1

- Corrigida a avaliação de força dos 18 clubes da Ligue 1.
- Cada clube agora possui uma classificação explícita de 2,5 a 5 estrelas, em vez de receber a classificação genérica aplicada a clubes internacionais sem avaliação cadastrada.
- A classificação alimenta os locais que consultam `clubStarRating`, incluindo seleção de clube, mercado e cálculo de força para simulações.
- Mantidos elencos, escudos, uniformes, calendário, competições e demais sistemas.
