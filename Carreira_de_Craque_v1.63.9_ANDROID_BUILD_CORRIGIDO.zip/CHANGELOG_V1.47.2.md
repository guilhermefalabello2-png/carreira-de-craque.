# Carreira de Craque v1.47.2 — Correções nas camisas

- **Santa Cruz:** camisa branca com três faixas horizontais no peito na ordem solicitada: vermelha em cima, branca no meio e preta embaixo.
- **Paysandu:** nome e número na parte de trás da camisa em azul.
- Alterações limitadas ao visual dos uniformes; não alteram tabelas, simulação, carreira ou outros clubes.
- Cache do PWA atualizado para carregar a versão nova.
