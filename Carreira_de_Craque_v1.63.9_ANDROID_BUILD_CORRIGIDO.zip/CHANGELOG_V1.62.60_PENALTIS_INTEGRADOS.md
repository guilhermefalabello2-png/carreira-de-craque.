# Carreira de Craque v1.62.60 — Pênaltis nas partidas e decisões

- Integração de ocorrência de pênalti nas partidas interativas normais.
- Frequência configurada em 8% por partida (considerando os dois times), para evitar excesso de penalidades.
- Quando o atleta do usuário está em campo, com confiança do treinador em 100% e média de precisão nas direções de pelo menos 70%, ele pode escolher a cobrança.
- Se os requisitos não forem cumpridos, a cobrança é simulada automaticamente por um companheiro ou adversário.
- Gol de pênalti durante o tempo regulamentar entra no placar e, se marcado pelo atleta do usuário, nas estatísticas normais.
- Disputas oficiais empatadas na Copa do Brasil agora são apresentadas uma cobrança por vez, com revelação gradual, morte súbita e escolha de direção quando chegar a vez do atleta do usuário.
- Gols da disputa não são contabilizados como gols normais da carreira.
- Mantidos os botões de cobrança em vermelho abaixo de 70% e verde a partir de 70%, sem cor laranja.
- Verificação de sintaxe JavaScript executada com sucesso (`node --check`).
