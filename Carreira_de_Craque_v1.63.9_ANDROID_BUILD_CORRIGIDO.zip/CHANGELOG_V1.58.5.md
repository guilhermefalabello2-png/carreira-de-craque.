# Carreira de Craque v1.58.5

- Coletivas pós-jogo agora oferecem respostas variadas, com cinco estilos de abordagem e seis formulações por estilo.
- As quatro opções de cada pergunta são sorteadas sem repetir o mesmo texto dentro da pergunta; a ordem também varia.
- As respostas mantêm efeitos distintos sobre moral, confiança, reputação e confiança do treinador.
- Mantida a coletiva obrigatória e a trava de progressão até a conclusão.
- Mantida a correção da classificação da v1.58.4.
- Limpeza inicial autorizada de carreiras salvas para iniciar os testes desta versão; a limpeza é executada uma única vez neste navegador/aparelho.
