CARREIRA DE CRAQUE v1.62.70e — ESCUDOS DA LIGUE 1 OFFLINE

- Incorporados os 18 escudos fornecidos pelo usuário em assets/escudos/.
- Imagens redimensionadas para até 256x256 px e otimizadas em PNG.
- Mapeados os 18 clubes da Ligue 1 para seus respectivos arquivos locais.
- A exibição dos escudos franceses não depende mais de URLs externas.
- Ajustado o cadastro visual dos clubes franceses para usar nome e iniciais corretos.
- Preservada a base v1.62.70d e o painel visual de pênaltis aprovado na v1.62.70.
