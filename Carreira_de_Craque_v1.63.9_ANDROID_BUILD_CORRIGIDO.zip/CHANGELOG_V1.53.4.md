# v1.53.4 — Integridade do Legado e validação de títulos

- Centraliza a validação de resultado histórico em `legacyResolveSeasonOutcome`.
- Para ligas profissionais, valida 380 jogos concluídos, 20 clubes, 38 aparições por clube e dois jogos por par de adversários.
- Snapshots novos carimbam temporada e competição nos jogos para rejeitar dados de outra temporada/competição.
- O Legado só exibe troféu se posição, campeão, tabela e jogos do mesmo registro forem consistentes.
- Registro de temporadas passa a atualizar o mesmo registro por carreira/temporada/competição/clube, evitando duplicação.
- Contabilização de títulos usa uma chave estável e só ocorre após validação do registro.
- Cache do service worker atualizado para garantir que a build nova substitua o shell anterior.
