# v1.62.93 LITE — Zonas de rebaixamento na aba LIGAS

- Corrigida a renderização da tabela independente aberta em **LIGAS > EUROPA** (`euroView`).
- Premier League, LaLiga e Serie A Enilive: três últimas posições em vermelho.
- Ligue 1: duas últimas posições em vermelho.
- Bundesliga: sem marcação vermelha.
- Ligas brasileiras não foram alteradas.
- Mantidas as regras já existentes na tela de carreira; esta correção garante que a indicação também apareça na navegação **LIGAS**.
