# Carreira de Craque v1.62.89 LITE — Ajuste visual da Bundesliga

- Removido da tela da Bundesliga o painel verde de resumo que exibia incorretamente “CAMPEONATO INGLÊS”.
- Corrigido o texto descritivo da Bundesliga para campeonato alemão, com 18 clubes e 34 rodadas.
- Corrigido o identificador superior da competição para “BUNDESLIGA”.
- Mantida a tabela de classificação e as demais telas/competições.
