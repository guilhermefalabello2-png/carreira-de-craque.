# Carreira de Craque v1.53.7 — Registro central de conquistas profissionais

- Criado `professionalAchievements` como fonte única de títulos profissionais confirmados.
- Registro validado por carreira, competição, temporada, ID de clube, encerramento e resultado final.
- Chave idempotente impede títulos duplicados após processar a mesma temporada novamente.
- O Legado profissional e a contagem de títulos consultam o registro central; abrir a tela não concede títulos.
- Migração segura preserva os históricos e importa somente títulos antigos que podem ser comprovados.
- O Sub-20 mantém suas tabelas, persistência e validação independentes.
- Validação separada para resultados de copas, sem aplicar regra de classificação de liga.
- Atualizado o cache do service worker.
