# Carreira de Craque v1.62.73 — Correção estrutural da Ligue 1

- Corrigida a identificação de carreiras francesas ao abrir e restaurar saves: clubes da Ligue 1 mantêm a chave `ligue1` e o modo de liga europeia.
- Corrigido o carregamento de saves franceses para não cair no fallback do Brasileirão por possuir 18 clubes e 34 rodadas.
- Corrigida a tela Ligas > Europa > França para exibir a classificação e os dados da Ligue 1, em vez da Série A brasileira.
- Criada rotina de reconstrução segura do calendário francês (18 clubes, 34 rodadas, 306 partidas) quando a associação do clube/calendário estiver ausente ou inconsistente.
- Corrigido o encerramento e avanço de temporada para validar o tamanho real da competição, sem exigir 38 rodadas/380 partidas.
- Corrigida a exibição da temporada francesa com 34 rodadas, 306 partidas e 17 jogos por clube.
- Corrigido o calendário após nova temporada e após transferência para clube francês.
- Preservados os sistemas das outras ligas e os dados da carreira; nenhuma limpeza de saves foi adicionada.

## v1.62.23 — Copa do Brasil em carreiras europeias

- Corrigido o erro ao abrir a Copa do Brasil em Ligas durante carreiras na Europa.
- A Copa usa sempre os 64 clubes brasileiros das Séries A, B e C + convidados, sem misturar clubes europeus.
- Saves com participantes incompatíveis são corrigidos preservando o histórico de campeões.
- A simulação automática da Copa continua avançando durante a carreira europeia.

## v1.62.22 — Gabriel Jesus no Barcelona
- Removido Robert Lewandowski do elenco do Barcelona.
- Gabriel Jesus incluído no Barcelona com a camisa 9, na posição ATA.
- Confirmado que Gabriel Jesus não consta no elenco do Arsenal.

## v1.62.21 — Elencos completos da LaLiga
- Inclusão dos 20 elencos enviados pelo usuário na temporada 2026/27.
- Aplicadas as correções de duplicidades e transferências informadas: Betis, Valencia, Elche, Alavés, Levante, Osasuna e Málaga.
- Elencos exibidos em Ligas Europeias > LaLiga e integrados à escalação/simulação de carreira para os clubes espanhóis.
- Overall de jogo estimado por posição e força do clube; não altera as estrelas cadastradas.

## v1.35.0 — Sub-20: calendário e avanço de rodadas
- Adicionada a seção de calendário do Sub-20 com os confrontos da próxima rodada.
- Adicionado botão para simular a próxima rodada do Sub-20, avançando o contador com base nos jogos concluídos.
- A tabela segue calculada pelos resultados efetivamente disputados.

## v1.30.0 — Correção do mata-mata Sub-20
- Corrigida a detecção do fim das 38 rodadas e a criação das semifinais.
- As semifinais são reconstruídas quando os dados salvos estão incompletos, sem sobrescrever confrontos válidos.
- Botões do mata-mata validam a disponibilidade antes de simular a partida.

## v1.26.2 — Salário pago no início de cada mês
- O salário deixou de ser creditado diariamente.
- O pagamento agora ocorre apenas no primeiro dia de cada mês do calendário da carreira, calculado a partir do salário semanal (52 semanas ÷ 12 meses).
- Empresários continuam sendo pagos com o saldo disponível; a compra exige juntar dinheiro até o próximo pagamento.

## v1.24.6 — Tabela Sub-20 conectada às partidas da carreira
- A tela Ligas → Brasil → SUB-20 agora lê os mesmos resultados e a mesma rodada disputados na carreira de base.
- Classificação, jogos e placares atualizam depois de jogar uma partida, em vez de ficarem parados numa tabela independente.
- Mantida a remoção do botão de simulação manual da rodada.

## v1.24.4 — Elencos Sub-20 genéricos em todos os clubes
- Corrigido o elenco da carreira na base: todos os jogadores do Sub-20 agora são fictícios, com nomes brasileiros, posições, idades e atributos próprios.
- A equipe Sub-20 de cada clube usa elenco separado do profissional; partidas e escalações na carreira de base não reutilizam os atletas reais do elenco principal.
- A tela Elenco passa a identificar claramente os jogadores como fictícios quando a carreira está no Sub-20.
- A competição independente verifica e substitui elencos antigos que não estejam marcados como genéricos para todos os 20 clubes.

## v1.24.2 — Brasileirão Sub-20 com mata-mata
- Corrigido o campeonato Sub-20 para ter 20 clubes, não 40.
- Fase de liga em 38 rodadas (ida e volta), 10 partidas por rodada.
- Os quatro primeiros avançam: 1º x 4º e 2º x 3º nas semifinais; vencedores disputam a final em jogo único.
- Resultados e classificação da competição ficam salvos separadamente das ligas profissionais.

## v1.23.8 — Reinício correto do Brasileirão em nova carreira
- Corrigido o painel independente de Série A e Série B em “Ligas”, que podia reaproveitar o estado salvo de uma carreira anterior e aparecer na 38ª rodada.
- Ao iniciar uma nova carreira, os dois campeonatos brasileiros independentes são recriados na temporada atual, na rodada 1, com calendário e classificação zerados.
- Adicionada validação de temporada e estrutura do calendário para recuperar dados antigos ou incompletos sem afetar o calendário das partidas da carreira.

## v1.23.6 — Titularidade dinâmica baseada no desempenho
- Removida a oscilação excessivamente aleatória entre titular, reserva e não relacionado a cada partida.
- A avaliação agora considera as últimas atuações da temporada, notas, gols, assistências, nível técnico, condição física e confiança do treinador.
- Duas boas atuações recentes podem consolidar a titularidade; sequência de notas baixas reduz a participação e pode levar ao banco ou, em sequência prolongada e com baixa confiança, à não relação.
- Lesão e suspensão continuam impedindo a escalação.

## v1.23.5 — Temporadas até os 40 anos e correção de avanço
- Adicionada proteção para evitar que a mesma temporada seja processada duas vezes.
- Corrigida a transição para a temporada seguinte, com rodada, calendário, tabela e estatísticas sazonais reiniciados.
- A carreira segue até o encerramento da temporada em que o jogador completa 40 anos; depois, o legado fica disponível e não há novas temporadas.
- Iniciando em 2026 aos 16 anos, o atleta pode jogar até a temporada 2050; começando aos 17, até 2049.

## v1.23.3 — Bandeira correta da Inglaterra
- Substituída a bandeira preta pela bandeira da Inglaterra (🏴󠁧󠁢󠁥󠁮󠁧󠁿) no menu de LIGAS e na seleção das competições europeias.
- Mantidas as bandeiras próprias da Itália, Alemanha, Espanha, França e Brasil.

## v1.23.0 — Ligas europeias com avanço automático
- Removidos os botões “Simular partidas desta rodada” e “Reiniciar temporada desta liga” da tela de ligas europeias.
- Ao concluir cada partida da carreira, as ligas europeias avançam automaticamente para a rodada correspondente, com placares salvos no aparelho.
- O calendário europeu continua navegável para consultar rodadas e classificação, sem exigir simulação manual.

## v1.22.8 — Menu inicial
- Criado menu inicial com “CRIAR NOVA CARREIRA” e “CONTINUAR CARREIRA”.
- “Continuar carreira” lista os saves existentes e permite retomar um deles sem apagar progresso.
- Adicionado acesso ao Instagram @guiii.__09.
- Adicionado botão para voltar ao menu inicial a partir da criação de carreira.

## v1.22.7 — Status pré-jogo e entrada no minuto da substituição
- Central de pré-jogo informa se o atleta será titular, reserva ou não relacionado.
- Para reservas, a partida avança até o minuto de entrada; a participação individual começa a partir desse momento.
- Titulares participam desde o início; não relacionados terminam sem minutos.

## v1.22.6 — Permanência mínima e propostas da Premier League
- O atleta precisa concluir uma temporada completa no clube atual antes de solicitar saída ou concluir uma transferência. A validação também ocorre ao confirmar a proposta, evitando contornar a regra por telas diferentes.
- Clubes da Premier League entram no mercado de propostas mesmo quando o jogador está em um clube brasileiro.
- Propostas da Premier League exigem mais reputação e desempenho; os grandes clubes exigem overall alto, sequência de jogos, participação direta em gols e boas notas.
- Propostas inglesas oferecem condições financeiras ajustadas ao mercado europeu.

## v1.22.5 — Brasileirão com avanço automático
- Removidos os controles “Simular rodada completa” e “Reiniciar esta Série”.
- Ao concluir uma partida da carreira, as rodadas correspondentes das Séries A e B avançam automaticamente, com resultados persistidos no aparelho.
- Acompanhar o Brasileirão não altera o resultado da partida do jogador.

## v1.22.4 — Brasileirão independente da carreira

- Brasil permanece acessível em LIGAS mesmo quando a carreira do jogador é na Inglaterra.
- Séries A e B têm calendário, resultados simulados, classificação e progresso salvos separadamente da carreira.
- Simular/reiniciar o Brasileirão não altera a carreira inglesa.
- Esta área simula os campeonatos localmente; resultados reais ao vivo exigem integração com uma API externa.

## v1.22.3 — Menu LIGAS reorganizado
- Removida a opção “Europa” da barra principal.
- Renomeada a opção “Brasileirão” para “LIGAS”.
- Criado menu por país: Brasil → Brasileirão A e B; Inglaterra → Premier League; demais ligas exibem “Dados do Jogador” e aviso de indisponibilidade.

## v1.22.2 — Cores das camisas inglesas
- Corrigidas as cores-base dos 20 clubes ingleses; cada uniforme usa a identidade cromática do próprio clube.
- Mantido o sistema de uniformes e a experiência dos clubes brasileiros.

## v1.22.2 — Escudos da Premier League
- Mapeados os 20 escudos ESPN fornecidos para os clubes ingleses.
- Mantidos transparentes, proporcionais e sem moldura.
- Observação: o carregamento dos escudos exige internet.

## v1.22.2 — Premier League jogável na carreira
- A criação de carreira permite escolher um dos 20 clubes ingleses da Premier League.
- A carreira inglesa recebe calendário próprio de 38 rodadas, classificação, jogos jogáveis no motor de partidas e persistência local.
- Elencos cadastrados da Premier League são usados para estimar a força dos adversários e identificar jogadores em eventos.
- O modo brasileiro Série A/B permanece separado e preservado.

# v1.20.1 — País e clube inicial

- Em Dados do Atleta, o campo Clube inicial agora é organizado por país: BRASIL, INGLATERRA, ESPANHA, FRANÇA, ALEMANHA e ITÁLIA.
- BRASIL lista os 40 clubes já cadastrados nas Séries A e B.
- INGLATERRA lista os 20 clubes da Premier League presentes na base europeia.
- Os clubes dos outros quatro países ficam sinalizados como “em breve”, para serem adicionados nas próximas atualizações.
- O país selecionado é salvo no cadastro inicial do atleta.
- A integração da temporada inglesa ao motor da carreira ainda será feita na atualização de Premier League jogável.

# v1.20.0 — Premier League jogável

- Adicionada base local de elencos da Premier League 2026/27 a partir das listas enviadas.
- Nova tabela de elenco por clube com camisa, posição e identificação visual de números repetidos.
- Mantidos calendário ida e volta, simulação por rodada, classificação e salvamento local já existentes.
- Preservada a tela pré-jogo e a estrutura das ligas brasileiras.
- Os dados de elenco são fornecidos pelo usuário e não foram verificados independentemente.

## v1.19.0 — Expansão Europeia inicial
- Adicionada a área Europa com Premier League (20 clubes), Serie A TIM (20), Bundesliga (18), LaLiga (20) e Ligue 1 (18), composição 2026/27.
- Calendário ida e volta gerado para cada liga, com 38 rodadas nas ligas de 20 clubes e 34 nas ligas de 18 clubes.
- Simulação de resultados por rodada, classificação automática e persistência local independente da carreira brasileira.
- Mantida a estrutura pré-jogo aprovada na v1.18.0.
- Limitação desta etapa: elencos completos licenciados, escudos e uniformes oficiais europeus ainda não foram integrados; não são apresentados como completos.

## v1.18.0 — Formação pré-jogo sem mistura
- Separação maior entre as duas equipes, cada uma na própria metade do campo.
- Campo mais alto e nomes/números ligeiramente maiores para melhorar a leitura no celular.
- Mantém 11 jogadores por equipe.

## v1.17.8 — Formação pré-jogo separada
- Corrigidas as coordenadas verticais da formação: cada equipe fica na própria metade do campo, com 11 posições por equipe e sem sobreposição entre as duas formações.

## v1.17.7 — Formação pré-jogo corrigida
- Separadas visualmente as duas escalações no campo, com 11 posições por equipe e sem sobreposição entre os jogadores.
- Ajustado o posicionamento vertical das equipes para mostrar um time em cada metade do campo.

## v1.17.6 — Escalações pré-jogo corrigidas
- Formação tática agora exibe 11 posições por equipe, em estrutura 4-3-3.
- Seleção automática prioriza jogadores disponíveis de cada posição e, em seguida, os melhores OVR restantes.
- O jogador da carreira aparece na posição mais compatível com sua posição cadastrada.
- Evita repetir o mesmo atleta na escalação.

## v1.17.5 — Camisa inicial automática
- Removido o campo “Camisa” da tela de criação em “Dados do atleta”.
- O jogo atribui automaticamente o primeiro número disponível de 1 a 99, priorizando os números preferenciais configurados, sem usar número já cadastrado no elenco do clube.

## v1.17.4 — Correção de números de camisa
- Bahia: Marco Moreno camisa 3; Gabriel Xavier movido para 14 para evitar duplicidade.
- Palmeiras: Arthur Gabriel 56, Maurício 18, Marlon Freitas 17, Andreas Pereira 8, Jhon Arias 11 e Paulinho 10.
- Vitória: Erick 33, Renê 91, Matheuzinho 10; Lucas Halter movido para 14 para evitar duplicidade.

# Changelog — v1.17.3

- Consolidação dos elencos dos 20 clubes da Série B com as listas Transfermarkt fornecidas pelo usuário em 26/10/2026.
- Números de camisa duplicados removidos por clube, priorizando a primeira ocorrência da lista.
- Para nomes separados por “/”, mantida apenas a primeira opção.
- Atualizados dados de elenco, fontes indicadas e data de referência no jogo e no arquivo JSON.
- Alguns clubes ficam com menos de 22 atletas porque a regra de prioridade remove entradas com numeração repetida; não foram inventados atletas para preencher vagas.

# v1.16.9 — Elenco Athletico-PR atualizado

- Atualizado o elenco do Athletico-PR com 21 atletas e numeração fornecida para 25/10/2026.
- Mantidos os demais sistemas e a estrutura da carreira.

# CHANGELOG

## v1.14.0 — Referências visuais reais de camisas 2026
- A prévia em JOGADOR → PERSONALIZAR pode exibir imagens de camisas reais hospedadas por páginas de referência/lojas, em vez de SVG genérico.
- Cada imagem tem origem registrada no manifesto e na interface.
- O catálogo cobre os 40 clubes e marca claramente os clubes sem imagem.
- As imagens são carregadas remotamente e exigem internet; não estão embutidas no ZIP porque a licença de redistribuição não foi confirmada.
- Não foram adicionadas vistas traseiras falsas nem reservas/terceiras genéricas.
- Saves, atributos, calendário, contratos e transferências não foram alterados.

# Changelog

## v1.12.0 — Catálogo visual de 40 clubes (2026)
- Expandido o catálogo de prévias vetoriais para os 40 clubes existentes no jogo.
- Adicionadas referências públicas de temporada e fornecedores, além de detalhes de design conhecidos.
- Patrocinadores só são exibidos quando identificados na referência consultada.
- Manifesto separa prévia vetorial de fotografia oficial: nenhuma foto oficial/licenciada foi incluída.
- Preservados carreira, progressão, campeonatos e saves.


## v1.16.7 — Diversidade de padrões de camisas
- A prévia traseira agora respeita o padrão cadastrado por clube, em vez de aplicar sempre quatro faixas horizontais.
- Adicionados padrões visuais distintos: camisa lisa/texturizada, faixas horizontais finas e múltiplas, listras verticais, faixa diagonal e painéis laterais.
- Refinadas escolhas de padrões para clubes como Vasco, Operário-PR, Vitória, Atlético-MG, Botafogo, Corinthians, Santos, Cruzeiro, Ponte Preta e Sport Recife.
- Nome e número seguem dinâmicos; cores continuam vindo do cadastro de cada uniforme. Nenhuma alteração intencional nos sistemas de carreira.


## v1.16.8 — Listras verticais ampliadas
- Corrigida a largura das listras verticais: agora alternam cores em faixas largas e contínuas, cobrindo o corpo da camisa de cima até a barra.
- Aplicado a padrões verticais comuns, múltiplas listras, tricolores, Fortaleza e Botafogo.
- Mantidos o molde, nome/número nas costas, demais padrões e sistemas do jogo.


## v1.17.0 — Elencos Série A (25/10/2026)
- Atualizados os 19 elencos enviados pelo usuário: Flamengo, Palmeiras, Corinthians, São Paulo, Santos, Cruzeiro, Atlético-MG, Grêmio, Internacional, Vasco, Fluminense, Botafogo, Remo, Chapecoense, Mirassol, Red Bull Bragantino, Bahia, Vitória e Coritiba.
- Mantido o elenco Athletico Paranaense já cadastrado na versão anterior.
- “Galo” consolidado como apelido do Atlético-MG, sem clube duplicado.
- Preservados os nomes, números e todos os jogadores listados; quando há números repetidos na lista recebida, eles são mantidos conforme informado.

## v1.23.1 — Status da escalação na tela Início
- Exibe ao lado de “Próximo compromisso” o status previsto do atleta: TITULAR (verde), RESERVA (amarelo) ou NÃO RELACIONADO (vermelho).
- A seleção é guardada para a rodada atual, mantendo o mesmo status ao abrir o pré-jogo e iniciar a partida.

## v1.23.9 — Ajustes pontuais em Jogador e calendário
- Removida a aba “Camisa do jogador” da seção Jogador; mantida a opção “Camisa” para os ajustes de numeração/uniforme que continuam úteis.
- No calendário da temporada, cada partida agora mostra o escudo do adversário, independentemente de jogar em casa ou fora.
- Adicionado marcador minimalista de casa (⌂) para jogos como mandante e avião (✈) para jogos como visitante.
- Se um save antigo estava aberto na aba removida, a tela volta automaticamente para Perfil.

## v1.24.1 — Sub-20 separado e seleção corrigida
- Carreiras iniciadas no Brasil começam aos 17 anos no Sub-20, com calendário da carreira identificado como base.
- Seleção brasileira rotulada como BRASIL SUB-20 e clubes listados como equipes Sub-20.
- Adicionada liga Sub-20 independente com 40 clubes, 78 rodadas e classificação própria no menu LIGAS.
- Brasileirão A, Brasileirão B e Premier League permanecem acessíveis como competições separadas.

## v1.24.3 — Elencos fictícios do Sub-20
- Cada um dos 20 clubes do Brasileirão Sub-20 agora possui um elenco próprio com nomes brasileiros fictícios, idades juvenis e atributos próprios.
- A tela da liga inclui consulta aos elencos Sub-20 por clube.
- Os elencos da base são persistidos separadamente e não reutilizam o cadastro de jogadores do profissional.
- A chave de armazenamento da competição foi atualizada para criar dados separados dos saves anteriores.


## v1.24.5 — Remoção do botão de simulação Sub-20 em Ligas
- Removido da tela LIGAS > Brasil > Sub-20 o botão “SIMULAR PRÓXIMA RODADA”.
- Mantidas as tabelas, calendário, resultados e mata-mata Sub-20.


## v1.24.8 — Menu Premier League simplificado
- Removida a seção “Elenco e Camisas” da página Premier League em Ligas.
- Mantidos intactos os dados de jogadores, clubes, camisas e elencos da Premier League; nenhuma lista de jogadores foi alterada.

## v1.24.9 — Remoção da consulta de elenco Sub-20 em Ligas
- Removida de LIGAS > Brasil > Sub-20 a seção de consulta “Elencos Sub-20”.
- Mantidos os jogadores fictícios Sub-20, seus atributos e os dados persistidos; a alteração afeta somente a seção exibida na tela.

## v1.25.0 — Promoção Sub-20 no momento correto
- A mensagem/opção de subir ao profissional não aparece antes de terminar o mata-mata Sub-20.
- Se terminar a fase de liga entre 5º e 20º, a opção aparece após a eliminação na fase de liga.
- Se ficar entre os quatro primeiros, aguarda as semifinais: quem for eliminado recebe a opção após a semifinal; quem chegar à final só recebe a opção depois da decisão, tanto para vice-campeão quanto para campeão.
- Mantida a progressão existente de promoção ou permanência na base.

## v1.25.1 — Ocultar rodadas e resultados na área LIGAS
- Removidos da interface de LIGAS os painéis de rodadas/resultados do Brasileirão Série A, Série B, Sub-20 e Premier League.
- Mantidos os calendários internos, resultados persistidos, atualização de tabelas e avanço automático dos campeonatos; a alteração é apenas visual e não muda o formato nem a simulação das competições.


## v1.26.0 — Sistema de empresário
- Ao criar uma carreira, aparece a tela/modal ‘Escolha seu empresário’.
- Cinco empresários fictícios, de 1 a 5 estrelas; o de 1 estrela é gratuito.
- Contratação e troca usando o dinheiro do jogo: 2★ R$ 5.000; 3★ R$ 20.000; 4★ R$ 75.000; 5★ R$ 200.000.
- Empresários com mais estrelas aumentam gradualmente a chance de receber propostas de transferência; propostas continuam dependendo do desempenho e não são garantidas.
- Área Vida profissional mostra o empresário atual e permite trocar/melhorar. Patrocínios ficam reservados para atualização futura.

## v1.26.1 — Acesso rápido a empresários e Caixa
- Adicionada a opção ‘Checar empresários’ no menu das três listras, permitindo consultar e contratar/trocar empresário a qualquer momento.
- Adicionada a seção ‘Caixa’ em JOGADOR, ao lado de ‘Camisa’, exibindo saldo atual, salário semanal, receitas, despesas, empresário atual e histórico financeiro.
- O saldo e as contratações continuam usando o dinheiro já existente na carreira; nenhuma regra de campeonato ou simulação foi alterada.

## v1.26.3 — Entrevistas pós-jogo e lesões equilibradas
- Entrevista coletiva contextual após derrota ou vitória importante, com três respostas que afetam reputação, moral, confiança e notícias.
- Lesões mantidas como eventos raros: a chance foi reduzida e depende de condição física muito baixa; afastamentos são curtos (3–8 dias).
- Calendários, formato dos campeonatos e simulação de resultados não foram alterados.

## v1.27.7
- Corrigido o calendário da carreira para alternar mandos do jogador: casa, fora, casa, fora, preservando rodadas já disputadas e ajustando apenas partidas futuras.


## v1.37.0 — Sub-20 sem mata-mata e sem clubes da Série B
- Removida a exibição de semifinais e final do Sub-20.
- Participantes do Sub-20 limitados aos clubes da Série A profissional.
- Mantida a fase de liga em 38 rodadas, sem botão manual de simulação.


## v1.40.0
- Seletor inicial “Brasil Sub-20” agora lista apenas os 20 clubes da Série A profissional para a carreira Sub-20 (contador 1/20).
- Série B profissional preservada no sistema profissional; apenas removida da lista de escolha para começar no Sub-20.

## v1.42.0 — Sistema salarial e empresários
- Salário mensal de referência de R$ 4.000 nas categorias de base e R$ 10.000 no início profissional.
- Valores contratuais semanais convertidos para pagamentos mensais, com tratamento específico do salário da base.
- Comissões de empresário aplicadas em renovação e assinatura de contrato: 5%, 8%, 12% ou 15% conforme nível.
- Base de cálculo da comissão: salários previstos durante a duração do contrato + bônus de assinatura.
- Comissões registradas no histórico financeiro e em notícias, sem taxa fixa adicional.
- Mantidas as estruturas das competições e o calendário existentes.

## v1.44.0 — Motor avançado de simulação de partidas
- Reequilibrada a força geral: estrelas, média dos titulares e profundidade do elenco entram com pesos separados, sem resultado fixo por clube.
- Resultados automáticos usam forças ofensivas/defensivas estimadas, variação por partida e vantagem de mando moderada; a distribuição de Poisson não corta artificialmente placares em seis gols.
- Jogos simulados passam a guardar estatísticas de partida coerentes com o placar: posse complementar em 100%, finalizações no alvo nunca inferiores aos gols, passes, precisão, escanteios, faltas e cartões.
- Preservados os caminhos existentes de atualização de tabela, registro de gols e prevenção de simulação duplicada.
- Validação de sintaxe JavaScript e testes automatizados de distribuição incluídos na entrega; não substituem teste visual completo no navegador.


## v1.46.1 — Escudos da Série C

Adicionados mapeamentos de escudos transparentes para os 20 clubes da Série C, reutilizando os arquivos SVG locais disponíveis e preservando o fallback para recursos indisponíveis.

## v1.46.5 — Série C funcional e zonas G4/Z4
- Destacadas as zonas G4 e Z4 nas tabelas nacionais com cores legíveis e legenda.
- Série A: G4 destacado e Z4 rebaixado à Série B.
- Série B: G4 sobe à Série A e Z4 cai à Série C.
- Série C: G4 destacado como acesso à Série B.
- Mantida a aplicação automática de acessos e rebaixamentos no encerramento da temporada.


## v1.46.8
- Corrigido G4 verde diretamente na tela **Ligas → Brasil**, com Z4 vermelho nas Séries A/B e legenda de zonas.

## v1.46.9 — Série C
- Corrigido o avanço das rodadas e a atualização da classificação da Série C em Ligas > Brasil, sem alterar as tabelas das Séries A e B.


## v1.47.0
- Corrigida a fonte da tabela da Série C em Ligas > Brasil, evitando que um snapshot antigo em `otherLeague` esconda a classificação atualizada.
- Sincronizada a Série C ao trocar de divisão; demais tabelas não foram alteradas.

## v1.47.1
- Fix: `Ligas > Brasil > Série C` ficava parada porque a função de avanço automático só percorria A e B. Agora inclui C sem mudar a lógica dessas duas divisões.

## v1.47.2 — Camisas Santa Cruz e Paysandu
- Santa Cruz: faixas horizontais vermelha, branca e preta no peito.
- Paysandu: nome e número azuis.

## v1.47.4
- Flamengo: listras horizontais pretas mais grossas, inspiradas na referência enviada.
- Atualização do cache PWA.

## v1.47.5 — Flamengo profissional e Sub-20
- Faixas horizontais rubro-negras mais largas na camisa titular, usando o padrão compartilhado pelas duas categorias.

## v1.47.6 — Flamengo fiel à referência
- Mangas e gola pretas; três faixas horizontais grossas (vermelha, preta, vermelha), com a primeira iniciando no alto do corpo. Alteração no padrão compartilhado do Flamengo, válida no profissional e Sub-20.


## v1.47.7 — Flamengo conforme a referência visual
- Corrigido o uniforme titular do Flamengo nos dois renderizadores (prévia do jogador e camisa ampliada): mangas e base do corpo pretas, primeira faixa vermelha começando perto do topo, faixa preta grossa no meio e segunda faixa vermelha grossa embaixo, com barra inferior preta.
- O mesmo padrão é usado pelo profissional e pelo Sub-20 por meio do catálogo compartilhado do clube.

## v1.50.0 — Elencos iniciais da Série C
- Incluídos 18 registros de jogadores por clube nos 20 clubes da Série C na estrutura principal de elencos, usada por escalações e partidas.
- A base de atletas passa de 744 para 1.104 registros e contempla os 60 clubes das Séries A, B e C.
- A Série C continua sendo a última divisão brasileira. Série D não foi criada.
- Importante: os elencos da Série C são uma base inicial de gameplay; nomes, posições, overall e números não foram verificados individualmente em fontes oficiais e precisam ser revisados antes de serem considerados dados oficiais.
