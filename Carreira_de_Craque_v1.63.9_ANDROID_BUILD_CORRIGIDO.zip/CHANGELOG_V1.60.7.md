# Carreira de Craque v1.60.7 — Uniformes conforme as referências

## Alterações
- Grêmio profissional e Sub-20: camisa titular com listras verticais azul-celeste/pretas, filetes claros, mangas pretas e nome/número dourados.
- Botafogo profissional e Sub-20: camisa titular branca com cinco listras pretas verticais, mangas escuras, estrela na nuca e nome/número brancos contornados em preto.
- Athletico Paranaense profissional e Sub-20: camisa titular preta com faixas diagonais vermelhas mais largas e punhos vermelhos.
- Vitória e Santos foram mantidos sem alteração intencional.
- Os ajustes foram aplicados aos dois renderizadores de uniforme do jogo (prévia do atleta e catálogo/visualização da camisa).

## Verificações
- JavaScript extraído do HTML passou em `node --check`.
- Arquivo ZIP verificado com `unzip -t`.
- Não foi realizado teste visual em aparelho Android nesta atualização.
