# v1.51.8 — Calendário associado ao clube correto

- Corrigida a normalização de nomes de clubes para evitar calendários gerados com um nome diferente do jogador salvo.
- A recuperação nacional agora procura o clube nas Séries A, B e C antes de escolher a divisão.
- A recuperação inglesa canonicaliza o clube para o nome oficial usado no calendário.
- A recuperação só informa sucesso se o calendário e a tabela realmente contiverem o clube atual.
- A sintaxe JavaScript foi verificada. O teste geral `tests/smoke-test.js` continua falhando numa verificação preexistente de inicialização do elenco real; a correção do calendário não foi validada em navegador com o save do usuário.
