# Carreira de Craque v1.62.61 — Treinamento e atributos de pênaltis

- Corrigido o escopo da função de leitura da precisão dos pênaltis: agora fica disponível globalmente para as telas de Treinamento e Jogador.
- Corrigido o erro que impedia a abertura da tela Treinamento.
- Adicionada em Jogador → Atributos a seção **Precisão nos pênaltis**, com barras e percentuais de ESQUERDA, MEIO e DIREITA.
- Exibida também a confiança do treinador e os requisitos para o atleta cobrar durante a partida.
- Saves antigos recebem os valores iniciais 55% / 45% / 55% somente quando ainda não possuem os atributos; progresso existente é preservado.
- Mantida a versão-base v1.62.60 e todas as demais funcionalidades.
