# v1.62.8 — Atualização dos escudos PNG da LaLiga

- Atualizados os endereços dos escudos de Real Madrid, Real Betis, Villarreal, Celta Vigo, Espanyol, Alavés, Deportivo La Coruña e Osasuna conforme os links enviados pelo usuário.
- Mantidos os demais 12 clubes, suas estrelas, cores, nomes e integração da LaLiga.
- Nenhuma alteração no calendário, nas partidas, na classificação ou nas demais ligas.

Observação: os escudos continuam sendo carregados pelos endereços HTTPS configurados; esta atualização altera os links, mas não incorpora os binários PNG ao pacote. A exibição depende de os servidores externos permitirem o acesso no navegador/dispositivo.
