# Carreira de Craque v1.62.68 — Ordem de Cobrança no Teste de Pênaltis

- A Área de Testes agora permite escolher em qual das cinco cobranças iniciais o jogador controlado vai bater.
- Os companheiros assumem automaticamente as outras posições.
- A escolha é exibida durante a disputa e respeitada mesmo quando a equipe começa cobrando em segundo.
- Se houver morte súbita, a sequência segue normalmente; o jogador não é inserido novamente após já ter cobrado.
- Mantidas as regras e o sistema de realismo das cobranças.
