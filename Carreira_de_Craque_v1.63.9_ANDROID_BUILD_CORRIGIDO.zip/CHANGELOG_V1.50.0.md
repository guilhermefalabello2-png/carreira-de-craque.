# Carreira de Craque v1.50.0 — Elencos Série C

- Integrados registros de atletas para gameplay dos 20 clubes da Série C.
- Os elencos são carregados pela mesma estrutura `REAL_ROSTERS` usada pelos demais clubes, portanto passam a aparecer em escalações, partidas e sistemas que consultam `rosterForClub`.
- Série C permanece como última divisão brasileira; nenhuma Série D foi criada.
- Mantida a estrutura anterior de ligas, escudos e calendário.
- Atenção: nomes são um cadastro inicial de gameplay e avaliações/numeração não foram verificados individualmente contra cadastro oficial; não apresentar OVR ou camisa como informação oficial.
