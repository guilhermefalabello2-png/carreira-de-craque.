# v1.62.92 LITE — Zonas de rebaixamento europeias

- Aplicada a zona vermelha em todas as ligas europeias, exceto Bundesliga.
- Premier League, LaLiga e Serie A Enilive: 18º, 19º e 20º.
- Ligue 1: 17º e 18º.
- Ligas brasileiras permanecem sem alteração.
- Bundesliga permanece sem marcação vermelha.
