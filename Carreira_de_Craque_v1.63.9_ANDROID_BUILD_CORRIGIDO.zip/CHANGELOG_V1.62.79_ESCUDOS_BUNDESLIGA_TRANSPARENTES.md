# Carreira de Craque v1.62.79 — Escudos Bundesliga com transparência real

- Substituídos os endereços externos dos 18 escudos da Bundesliga por arquivos PNG locais em `assets/escudos/`.
- Incorporados os 18 escudos fornecidos no pacote Bundesliga.zip.
- Normalizados para PNG RGBA em 512×512, preservando proporções e canal alpha.
- Removida a cor de fundo azul externa do arquivo do Hamburger SV.
- Mantido o sistema de renderização de escudos já existente no jogo.
- Nenhum escudo das demais ligas foi alterado.
- Não foram apagadas carreiras/saves.
