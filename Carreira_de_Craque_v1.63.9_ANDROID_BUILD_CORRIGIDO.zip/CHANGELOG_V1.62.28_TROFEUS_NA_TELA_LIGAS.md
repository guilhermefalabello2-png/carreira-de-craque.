# v1.62.28 — Troféus na tela principal de LIGAS

- Adicionada à tela principal de **LIGAS** uma galeria horizontal de sete troféus em PNG, seguindo a referência enviada.
- Inclui Série A, Série B, Série C, Copa do Brasil, Sub-20, LaLiga e Premier League.
- As imagens são arquivos locais com transparência, funcionando offline; a galeria permite rolagem horizontal em telas menores.
- Alteração exclusivamente visual: nenhuma regra de competição, calendário, classificação, elenco ou salvamento foi modificada.
